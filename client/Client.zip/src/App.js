import { RoutersProvider } from './router';

function App() {
  return (
    <div >
      <RoutersProvider/>
      
    </div>
  );
}

export default App;
