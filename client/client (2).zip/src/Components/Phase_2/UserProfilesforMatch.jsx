import React, { useState } from "react";

const users = [
  { id: 1, name: "Ali", age: 28, gender: "Male", bio: "Software Engineer", image: "/male1.jpg" },
  { id: 2, name: "Sara", age: 24, gender: "Female", bio: "UI Designer", image: "/female1.jpg" },
  { id: 3, name: "Ahmed", age: 30, gender: "Male", bio: "Product Manager", image: "/male2.jpg" },
  { id: 4, name: "Ayesha", age: 26, gender: "Female", bio: "Marketing Lead", image: "/female2.jpg" },
  { id: 5, name: "Sam", age: 22, gender: "Other", bio: "Content Creator", image: "/other1.jpg" },
];

const genders = ["Male", "Female", "Other"];

const UserProfiles = () => {
  const [selectedGender, setSelectedGender] = useState("Male");

  const filteredUsers = users.filter((user) => user.gender === selectedGender);

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold text-center mb-6">User Profiles</h1>

      {/* Gender Tabs */}
      <div className="flex justify-center gap-4 mb-8">
        {genders.map((gender) => (
          <button
            key={gender}
            onClick={() => setSelectedGender(gender)}
            className={`px-4 py-2 rounded-full border text-sm font-medium ${
              selectedGender === gender
                ? "bg-blue-600 text-white"
                : "bg-white text-blue-600 border-blue-600"
            }`}
          >
            {gender}
          </button>
        ))}
      </div>

      {/* Profile Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {filteredUsers.map((user) => (
          <div key={user.id} className="bg-white rounded-2xl shadow p-4 text-center">
            <img
              src={user.image}
              alt={user.name}
              className="w-24 h-24 rounded-full mx-auto object-cover mb-4"
            />
            <h2 className="text-lg font-semibold">{user.name}</h2>
            <p className="text-gray-500 text-sm">{user.age} years old</p>
            <p className="text-gray-600 mt-2">{user.bio}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default UserProfiles;
